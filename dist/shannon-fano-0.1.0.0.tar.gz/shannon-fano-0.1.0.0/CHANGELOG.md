# Revision history for shannon-fano

## 0.1.0.0 -- 02/11/2018

* First version.
